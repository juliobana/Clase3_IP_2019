#ifndef FUNCIONESARRAYS_H_INCLUDED
#define FUNCIONESARRAYS_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#include "funcionesArrays.h"
int imprimirArrayInt(int *pArray , int limite);
int cargarArrayInt(int *pArray , int limite, int valor);


#endif // FUNCIONESARRAYS_H_INCLUDED
