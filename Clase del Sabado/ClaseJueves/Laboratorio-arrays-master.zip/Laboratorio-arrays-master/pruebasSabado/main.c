#include <stdio.h>
#include <stdlib.h>

int main()
{


}
int DameElMaximo(int parametrosArray[indice];int cant)
 int indice;
 int maximo;
// sacar el maximo
 for(indice=0;indice<cant;indice++){
    if(indice ==0 || parametrosArray[indice]>maximo){
        maximo=parametrosArray[indice];
    }
 }
return maximo;

/**************************************************/
int DameElIndiceMaximo(int parametrosArray[];int cant)
 int indice;
 int IndiceDelMaximo;
for(indice=0;indice<cant;indice++){
    if(indice ==0 || parametrosArray[indice]>maximo){
        maximo=parametrosArray[indice];
        IndiceDelMaximo=indice;
    }
 }
return IndiceDelMaximo;
